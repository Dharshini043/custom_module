Employee Sequence:
=========================================================

Go to Setting / apps and search "Employee / Employee Sequence" and Install

And, you are done with installation. Congratulations!
